package httpd;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import java.io.InputStream;
import java.io.DataInputStream;

public class HttpServer 
{ 
    private int port = 8080;
    private String hostIp = "127.0.0.1";
    private ServerSocket server = null;
    private boolean isRunning = true;

	public HttpServer()
    { 
		try {
            server = new ServerSocket(this.port, 100, InetAddress.getByName(this.hostIp));
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public HttpServer(int port, String hostIp)
    { 
        this.port = port;
        this.hostIp = hostIp;
	 }
    
    public void exec() {
       try {
            server = new ServerSocket(this.port, 100, InetAddress.getByName(this.hostIp));
        } catch(Exception e) {
            e.printStackTrace();
            throw new Error("DEAD");
        }
   
        while(isRunning == true) {
            Socket client = null;

            try {
                client = server.accept();

                System.out.println("Connexion client reçue.");

                InputStream is = client.getInputStream();
                char c;
                int i;

                while( (i = is.read()) != -1) {
                    c = (char) i;
                    System.out.print(c);
                }

                

            } catch(Exception e) {
                e.printStackTrace();
            }
            finally 
            {
              try { client.close(); } catch(Exception e) { /** on s'en fout*/}
            }
        }
    }
    
    public void close() {
        this.isRunning = false;
        this.server = null;
    }
}