package httpd;

import java.net.ServerSocket;
import java.util.Arrays;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Main 
{ 
    
    
	public static void main( String[] args ) 
    { 
        String fileName = args[0];
        ConfigReader fr = new ConfigReader(fileName);
        
        String[] configParam = fr.read();

        
        try {
            HttpServer server = new HttpServer(Integer.parseInt(configParam[0]), configParam[1]);
            System.out.println("Open Socket on the port : "+configParam[0]);
            server.exec();
            System.out.println("Closing the server...");
            server.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
		
    }

}